//
//  KSHTTPServiceInvoker.h
//  SyncNetworkUtil
//
//  Created by Girish Lingarajappa Haniyamballi on 25/11/16.
//  Copyright © 2016 Girish Lingarajappa Haniyamballi. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "KSHTTPRequest.h"
#import "KSNetConstants.h"

@interface KSHTTPServiceInvoker : NSObject

/**
 Creates a service invoker with the given url string and options.
 

 @param URLString endpoint URL for the request
 @param optionsDictionary In iOS is used to override background sync behviour and allow selfsigned certificates.
        Passing options dictionary @{BACKGROUND_SYNC_ENABLED:FALSE} will disable background sync.
        By default these APIs run in background mode.
 @return KSHTTPServiceInvoker instance using the URL passed.
 */
- (instancetype)initWithURLString:(NSString *)URLString
                       andOptions:(NSDictionary *)optionsDictionary;


/**
 Creates a service invoker with the given request object and options.

 @param request of type KSHTTPRequest with necessary parameters set.
 @param optionsDictionary optionsDictionary In iOS is used to override background sync behviour and allow selfsigned certificates.
        Passing options dictionary @{BACKGROUND_SYNC_ENABLED:FALSE} will disable background sync.
        By default these APIs run in background mode.
 @return KSHTTPServiceInvoker instance initialised using the request passed.
 */
- (instancetype)initWithRequest:(KSHTTPRequest *)request
                     andOptions:(NSDictionary *)optionsDictionary;


/**
 Fires the request with the configured url or  request parameters using above init method.

 @param completionHandler the completion block ( comletionHandler(NSData* data, KSNetServicePhase servicePhase, NSError *error )) is called with received data and error if any.
 */
- (void)invokeWithCompletionHandler:(KSNetworkCompletionHandler)completionHandler;

@end

