//
//  KSNetworkUtils.h
//  KonySyncV2
//
//  Created by MADP on 29/09/16.
//  Copyright © 2016 Kony. All rights reserved.
//

#import <Task/KSTask.h>
#import <Foundation/Foundation.h>

#import "KSHTTPRequest.h"

@class NetworkError;
@class KSDownloadResponseMetadata;

@interface KSNetworkUtils : KSTask

+ (void)getResponse:(NSString *)syncServerAddress
             method:(KSHTTPMethod)method
       withCallback:(void(^)(NSString *data,NetworkError *error))callback;

+ (void)getResponse:(NSString *)syncServerAddress
             method:(KSHTTPMethod)method
        withHeaders:(NSDictionary *)headers
               body:(NSString *)bodyString
           callback:(void(^)(NSString *data,NetworkError *error))callback;

+ (void)getResponse:(NSString *)syncServerAddress
             method:(KSHTTPMethod)method
        withHeaders:(NSDictionary *)headers
        queryParams:(NSDictionary *)queryParams
               body:(NSString *)bodyString
           callback:(void(^)(NSString *data,NetworkError *error))callback;

+ (void)checkForErrorsInMetadata:(KSDownloadResponseMetadata *)metadata
                           error:(NetworkError **)error;

+ (void)checkHTTPStatusCode:(NSInteger)HTTPStatusCode
                      error:(NetworkError **)error;

+ (void)checkOpStatus:(NSInteger)opStatus
                error:(NetworkError **)error;

+ (void)checkErrorCode:(NSInteger)errorCode
          errorMessage:(NSString *)errorMessage
                 error:(NetworkError **)error;

@end
